package transformation;

import java.awt.Graphics;

public abstract class DrawingObject {
	abstract void draw(Graphics g);
}
